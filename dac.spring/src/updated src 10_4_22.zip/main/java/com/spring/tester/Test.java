//package com.spring.tester;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.spring.dao.AppointmentDAOInterface;
//import com.spring.models.Patient;
//
//
//public class Test {
//
//
//	AppointmentDAOInterface appointmentDAOInterface  ;
//	
//	Patient p = appointmentDAOInterface.findFirstnameByAndPatientId(1);
//	
//}
