import Gynac from "../../images/Gynac.jpg"
import Physio from "../../images/Physio.jpg"
import Pediatric from "../../images/Pediatric.jpg"
import Neuro from "../../images/Neuro.jpg"
import Dibetics from "../../images/Diabetics.jpg"
import Dentist from "../../images/Dentist.jpg"
import Oncologist from "../../images/oncologist.jpg"
const SpecialData = [
    {
        imgsrc: Gynac,
        title: "Gynacologist"
    },
    {
        imgsrc: Physio,
        title: "PhysioTherapist"
    },
    {
        imgsrc: Dibetics,
        title: "Diabetics"
    },{
        imgsrc: Oncologist,
        title: "Oncologist"
    },{
        imgsrc: Neuro,
        title: "Nuerologist"
    },{
        imgsrc: Pediatric,
        title: "Pediatric"
    },{
        imgsrc: Dentist,
        title: "Dentist"
    }
]

export default SpecialData;