import React from 'react'

const Footer = () => {
    return (
        <>
        <footer className="bg-light text-center footer">
            <p>&copy; 2022 Medicon. All RIghts Reserved | Terms and Condition.</p>
        </footer>
        </>
    )
}

export default Footer;